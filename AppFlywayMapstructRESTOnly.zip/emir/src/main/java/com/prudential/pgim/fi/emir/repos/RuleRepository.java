package com.prudential.pgim.fi.emir.repos;

import com.prudential.pgim.fi.emir.domain.Rule;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RuleRepository extends JpaRepository<Rule, Long> {

    Page<Rule> findAllById(Long id, Pageable pageable);

    boolean existsByNameIgnoreCase(String name);

}
