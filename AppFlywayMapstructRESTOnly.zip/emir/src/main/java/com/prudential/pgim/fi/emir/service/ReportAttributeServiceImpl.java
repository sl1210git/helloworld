package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.ReportAttribute;
import com.prudential.pgim.fi.emir.model.ReportAttributeDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.ReportAttributeRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportAttributeServiceImpl implements ReportAttributeService {

    private final ReportAttributeRepository reportAttributeRepository;
    private final ReportAttributeMapper reportAttributeMapper;

    public ReportAttributeServiceImpl(final ReportAttributeRepository reportAttributeRepository,
            final ReportAttributeMapper reportAttributeMapper) {
        this.reportAttributeRepository = reportAttributeRepository;
        this.reportAttributeMapper = reportAttributeMapper;
    }

    @Override
    public SimplePage<ReportAttributeDTO> findAll(final String filter, final Pageable pageable) {
        Page<ReportAttribute> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportAttributeRepository.findAllById(longFilter, pageable);
        } else {
            page = reportAttributeRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportAttribute -> reportAttributeMapper.updateReportAttributeDTO(reportAttribute, new ReportAttributeDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportAttributeDTO get(final Long id) {
        return reportAttributeRepository.findById(id)
                .map(reportAttribute -> reportAttributeMapper.updateReportAttributeDTO(reportAttribute, new ReportAttributeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ReportAttributeDTO reportAttributeDTO) {
        final ReportAttribute reportAttribute = new ReportAttribute();
        reportAttributeMapper.updateReportAttribute(reportAttributeDTO, reportAttribute);
        return reportAttributeRepository.save(reportAttribute).getId();
    }

    @Override
    public void update(final Long id, final ReportAttributeDTO reportAttributeDTO) {
        final ReportAttribute reportAttribute = reportAttributeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        reportAttributeMapper.updateReportAttribute(reportAttributeDTO, reportAttribute);
        reportAttributeRepository.save(reportAttribute);
    }

    @Override
    public void delete(final Long id) {
        reportAttributeRepository.deleteById(id);
    }

    @Override
    public boolean nameExists(final String name) {
        return reportAttributeRepository.existsByNameIgnoreCase(name);
    }

}
