package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.ReportAttributeValidValue;
import com.prudential.pgim.fi.emir.model.ReportAttributeValidValueDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;


@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface ReportAttributeValidValueMapper {

    ReportAttributeValidValueDTO updateReportAttributeValidValueDTO(
            ReportAttributeValidValue reportAttributeValidValue,
            @MappingTarget ReportAttributeValidValueDTO reportAttributeValidValueDTO);

    @Mapping(target = "id", ignore = true)
    ReportAttributeValidValue updateReportAttributeValidValue(
            ReportAttributeValidValueDTO reportAttributeValidValueDTO,
            @MappingTarget ReportAttributeValidValue reportAttributeValidValue);

}
