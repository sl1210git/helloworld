package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.ReportAttributeValidValue;
import com.prudential.pgim.fi.emir.model.ReportAttributeValidValueDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.ReportAttributeValidValueRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportAttributeValidValueServiceImpl implements ReportAttributeValidValueService {

    private final ReportAttributeValidValueRepository reportAttributeValidValueRepository;
    private final ReportAttributeValidValueMapper reportAttributeValidValueMapper;

    public ReportAttributeValidValueServiceImpl(
            final ReportAttributeValidValueRepository reportAttributeValidValueRepository,
            final ReportAttributeValidValueMapper reportAttributeValidValueMapper) {
        this.reportAttributeValidValueRepository = reportAttributeValidValueRepository;
        this.reportAttributeValidValueMapper = reportAttributeValidValueMapper;
    }

    @Override
    public SimplePage<ReportAttributeValidValueDTO> findAll(final String filter,
            final Pageable pageable) {
        Page<ReportAttributeValidValue> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportAttributeValidValueRepository.findAllById(longFilter, pageable);
        } else {
            page = reportAttributeValidValueRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportAttributeValidValue -> reportAttributeValidValueMapper.updateReportAttributeValidValueDTO(reportAttributeValidValue, new ReportAttributeValidValueDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportAttributeValidValueDTO get(final Long id) {
        return reportAttributeValidValueRepository.findById(id)
                .map(reportAttributeValidValue -> reportAttributeValidValueMapper.updateReportAttributeValidValueDTO(reportAttributeValidValue, new ReportAttributeValidValueDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ReportAttributeValidValueDTO reportAttributeValidValueDTO) {
        final ReportAttributeValidValue reportAttributeValidValue = new ReportAttributeValidValue();
        reportAttributeValidValueMapper.updateReportAttributeValidValue(reportAttributeValidValueDTO, reportAttributeValidValue);
        return reportAttributeValidValueRepository.save(reportAttributeValidValue).getId();
    }

    @Override
    public void update(final Long id,
            final ReportAttributeValidValueDTO reportAttributeValidValueDTO) {
        final ReportAttributeValidValue reportAttributeValidValue = reportAttributeValidValueRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        reportAttributeValidValueMapper.updateReportAttributeValidValue(reportAttributeValidValueDTO, reportAttributeValidValue);
        reportAttributeValidValueRepository.save(reportAttributeValidValue);
    }

    @Override
    public void delete(final Long id) {
        reportAttributeValidValueRepository.deleteById(id);
    }

    @Override
    public boolean attributeValueExists(final String attributeValue) {
        return reportAttributeValidValueRepository.existsByAttributeValueIgnoreCase(attributeValue);
    }

}
