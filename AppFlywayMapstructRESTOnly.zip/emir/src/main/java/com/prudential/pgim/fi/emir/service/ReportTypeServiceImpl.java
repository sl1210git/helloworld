package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.ReportType;
import com.prudential.pgim.fi.emir.model.ReportTypeDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.ReportTypeRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportTypeServiceImpl implements ReportTypeService {

    private final ReportTypeRepository reportTypeRepository;
    private final ReportTypeMapper reportTypeMapper;

    public ReportTypeServiceImpl(final ReportTypeRepository reportTypeRepository,
            final ReportTypeMapper reportTypeMapper) {
        this.reportTypeRepository = reportTypeRepository;
        this.reportTypeMapper = reportTypeMapper;
    }

    @Override
    public SimplePage<ReportTypeDTO> findAll(final String filter, final Pageable pageable) {
        Page<ReportType> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportTypeRepository.findAllById(longFilter, pageable);
        } else {
            page = reportTypeRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportType -> reportTypeMapper.updateReportTypeDTO(reportType, new ReportTypeDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportTypeDTO get(final Long id) {
        return reportTypeRepository.findById(id)
                .map(reportType -> reportTypeMapper.updateReportTypeDTO(reportType, new ReportTypeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ReportTypeDTO reportTypeDTO) {
        final ReportType reportType = new ReportType();
        reportTypeMapper.updateReportType(reportTypeDTO, reportType);
        return reportTypeRepository.save(reportType).getId();
    }

    @Override
    public void update(final Long id, final ReportTypeDTO reportTypeDTO) {
        final ReportType reportType = reportTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        reportTypeMapper.updateReportType(reportTypeDTO, reportType);
        reportTypeRepository.save(reportType);
    }

    @Override
    public void delete(final Long id) {
        reportTypeRepository.deleteById(id);
    }

    @Override
    public boolean nameExists(final String name) {
        return reportTypeRepository.existsByNameIgnoreCase(name);
    }

}
