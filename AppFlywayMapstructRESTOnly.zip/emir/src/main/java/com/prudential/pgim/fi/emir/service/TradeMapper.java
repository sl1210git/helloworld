package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Trade;
import com.prudential.pgim.fi.emir.model.TradeDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;


@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface TradeMapper {

    TradeDTO updateTradeDTO(Trade trade, @MappingTarget TradeDTO tradeDTO);

    @Mapping(target = "id", ignore = true)
    Trade updateTrade(TradeDTO tradeDTO, @MappingTarget Trade trade);

}
