package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Valuation;
import com.prudential.pgim.fi.emir.model.ValuationDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;


@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface ValuationMapper {

    ValuationDTO updateValuationDTO(Valuation valuation, @MappingTarget ValuationDTO valuationDTO);

    @Mapping(target = "id", ignore = true)
    Valuation updateValuation(ValuationDTO valuationDTO, @MappingTarget Valuation valuation);

}
