package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Valuation;
import com.prudential.pgim.fi.emir.model.ValuationDTO;
import com.prudential.pgim.fi.emir.repos.ValuationRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ValuationServiceImpl implements ValuationService {

    private final ValuationRepository valuationRepository;
    private final ValuationMapper valuationMapper;

    public ValuationServiceImpl(final ValuationRepository valuationRepository,
            final ValuationMapper valuationMapper) {
        this.valuationRepository = valuationRepository;
        this.valuationMapper = valuationMapper;
    }

    @Override
    public List<ValuationDTO> findAll() {
        final List<Valuation> valuations = valuationRepository.findAll(Sort.by("id"));
        return valuations.stream()
                .map(valuation -> valuationMapper.updateValuationDTO(valuation, new ValuationDTO()))
                .toList();
    }

    @Override
    public ValuationDTO get(final Long id) {
        return valuationRepository.findById(id)
                .map(valuation -> valuationMapper.updateValuationDTO(valuation, new ValuationDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ValuationDTO valuationDTO) {
        final Valuation valuation = new Valuation();
        valuationMapper.updateValuation(valuationDTO, valuation);
        return valuationRepository.save(valuation).getId();
    }

    @Override
    public void update(final Long id, final ValuationDTO valuationDTO) {
        final Valuation valuation = valuationRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        valuationMapper.updateValuation(valuationDTO, valuation);
        valuationRepository.save(valuation);
    }

    @Override
    public void delete(final Long id) {
        valuationRepository.deleteById(id);
    }

}
