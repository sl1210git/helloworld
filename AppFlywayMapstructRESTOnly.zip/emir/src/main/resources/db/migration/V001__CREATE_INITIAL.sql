CREATE SEQUENCE  IF NOT EXISTS primary_sequence START WITH 10000 INCREMENT BY 1;

CREATE TABLE rule (
    id BIGINT NOT NULL,
    name VARCHAR(80) NOT NULL,
    description TEXT,
    if_condition TEXT NOT NULL,
    then_condition TEXT NOT NULL,
    ordering INTEGER,
    group_name VARCHAR(80),
    disabled BOOLEAN NOT NULL,
    created_by_id VARCHAR(50),
    revised_by_id VARCHAR(50),
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT rule_pkey PRIMARY KEY (id)
);

CREATE TABLE trade (
    id BIGINT NOT NULL,
    cusip VARCHAR(9) NOT NULL,
    fund INTEGER NOT NULL,
    portfolio VARCHAR(50) NOT NULL,
    product_class VARCHAR(255) NOT NULL,
    asset_class VARCHAR(255) NOT NULL,
    contact_type VARCHAR(255) NOT NULL,
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT trade_pkey PRIMARY KEY (id)
);

CREATE TABLE valuation (
    id BIGINT NOT NULL,
    cusip VARCHAR(9) NOT NULL,
    fund INTEGER NOT NULL,
    portfolio VARCHAR(50) NOT NULL,
    pos_cur_face DOUBLE PRECISION NOT NULL,
    pos_cur_par DOUBLE PRECISION NOT NULL,
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT valuation_pkey PRIMARY KEY (id)
);

CREATE TABLE report_type (
    id BIGINT NOT NULL,
    name VARCHAR(80) NOT NULL,
    description TEXT,
    display_name VARCHAR(255) NOT NULL,
    created_by_id VARCHAR(50),
    revised_by_id VARCHAR(50),
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT report_type_pkey PRIMARY KEY (id)
);

CREATE TABLE report_attribute (
    id BIGINT NOT NULL,
    name VARCHAR(80) NOT NULL,
    description TEXT,
    display_name VARCHAR(255) NOT NULL,
    report_type_id INTEGER NOT NULL,
    default_value TEXT,
    ordering INTEGER,
    created_by_id VARCHAR(50),
    revised_by_id VARCHAR(50),
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT report_attribute_pkey PRIMARY KEY (id)
);

CREATE TABLE report_attribute_valid_value (
    id BIGINT NOT NULL,
    attribute_value VARCHAR(80) NOT NULL,
    display_name VARCHAR(255),
    value TEXT,
    ordering INTEGER,
    created_by_id VARCHAR(50),
    revised_by_id VARCHAR(50),
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT report_attribute_valid_value_pkey PRIMARY KEY (id)
);

ALTER TABLE rule ADD CONSTRAINT unique_rule_name UNIQUE (name);

ALTER TABLE report_type ADD CONSTRAINT unique_report_type_name UNIQUE (name);

ALTER TABLE report_attribute ADD CONSTRAINT unique_report_attribute_name UNIQUE (name);

ALTER TABLE report_attribute_valid_value ADD CONSTRAINT unique_report_attribute_valid_value_attribute_value UNIQUE (attribute_value);

