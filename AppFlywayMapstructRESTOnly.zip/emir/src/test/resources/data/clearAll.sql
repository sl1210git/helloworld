DELETE FROM rule;

DELETE FROM trade;

DELETE FROM valuation;

DELETE FROM report_type;

DELETE FROM report_attribute;

DELETE FROM report_attribute_valid_value;
