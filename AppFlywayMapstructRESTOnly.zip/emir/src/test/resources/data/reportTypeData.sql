INSERT INTO report_type (
    id,
    name,
    description,
    display_name,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1300,
    'Duis autem vel.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Ut wisi enim.',
    'Duis autem vel.',
    'Lorem ipsum dolor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO report_type (
    id,
    name,
    description,
    display_name,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1301,
    'Ut wisi enim.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    'Nam liber tempor.',
    'Ut wisi enim.',
    'Duis autem vel.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
