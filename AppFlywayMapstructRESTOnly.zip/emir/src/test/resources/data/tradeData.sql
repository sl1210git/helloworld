INSERT INTO trade (
    id,
    cusip,
    fund,
    portfolio,
    product_class,
    asset_class,
    contact_type,
    date_created,
    last_updated
) VALUES (
    1100,
    'Ut wisi e',
    29,
    'Nam liber tempor.',
    'Duis autem vel.',
    'Nam liber tempor.',
    'Nam liber tempor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO trade (
    id,
    cusip,
    fund,
    portfolio,
    product_class,
    asset_class,
    contact_type,
    date_created,
    last_updated
) VALUES (
    1101,
    'Nam liber',
    30,
    'Sed ut perspiciatis.',
    'Ut wisi enim.',
    'Sed ut perspiciatis.',
    'Sed ut perspiciatis.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
