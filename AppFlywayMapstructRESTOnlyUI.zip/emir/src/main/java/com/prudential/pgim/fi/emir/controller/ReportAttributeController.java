package com.prudential.pgim.fi.emir.controller;

import com.prudential.pgim.fi.emir.model.ReportAttributeDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.service.ReportAttributeService;
import com.prudential.pgim.fi.emir.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.SortDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/reportAttributes")
public class ReportAttributeController {

    private final ReportAttributeService reportAttributeService;

    public ReportAttributeController(final ReportAttributeService reportAttributeService) {
        this.reportAttributeService = reportAttributeService;
    }

    @GetMapping
    public String list(@RequestParam(required = false) final String filter,
            @SortDefault(sort = "id") @PageableDefault(size = 20) final Pageable pageable,
            final Model model) {
        final SimplePage<ReportAttributeDTO> reportAttributes = reportAttributeService.findAll(filter, pageable);
        model.addAttribute("reportAttributes", reportAttributes);
        model.addAttribute("filter", filter);
        model.addAttribute("paginationModel", WebUtils.getPaginationModel(reportAttributes));
        return "reportAttribute/list";
    }

    @GetMapping("/add")
    public String add(
            @ModelAttribute("reportAttribute") final ReportAttributeDTO reportAttributeDTO) {
        return "reportAttribute/add";
    }

    @PostMapping("/add")
    public String add(
            @ModelAttribute("reportAttribute") @Valid final ReportAttributeDTO reportAttributeDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (!bindingResult.hasFieldErrors("name") && reportAttributeService.nameExists(reportAttributeDTO.getName())) {
            bindingResult.rejectValue("name", "Exists.reportAttribute.name");
        }
        if (bindingResult.hasErrors()) {
            return "reportAttribute/add";
        }
        reportAttributeService.create(reportAttributeDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("reportAttribute.create.success"));
        return "redirect:/reportAttributes";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable final Long id, final Model model) {
        model.addAttribute("reportAttribute", reportAttributeService.get(id));
        return "reportAttribute/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable final Long id,
            @ModelAttribute("reportAttribute") @Valid final ReportAttributeDTO reportAttributeDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        final ReportAttributeDTO currentReportAttributeDTO = reportAttributeService.get(id);
        if (!bindingResult.hasFieldErrors("name") &&
                !reportAttributeDTO.getName().equalsIgnoreCase(currentReportAttributeDTO.getName()) &&
                reportAttributeService.nameExists(reportAttributeDTO.getName())) {
            bindingResult.rejectValue("name", "Exists.reportAttribute.name");
        }
        if (bindingResult.hasErrors()) {
            return "reportAttribute/edit";
        }
        reportAttributeService.update(id, reportAttributeDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("reportAttribute.update.success"));
        return "redirect:/reportAttributes";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable final Long id, final RedirectAttributes redirectAttributes) {
        reportAttributeService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("reportAttribute.delete.success"));
        return "redirect:/reportAttributes";
    }

}
