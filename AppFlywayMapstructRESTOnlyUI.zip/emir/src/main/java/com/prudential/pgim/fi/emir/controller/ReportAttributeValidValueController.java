package com.prudential.pgim.fi.emir.controller;

import com.prudential.pgim.fi.emir.model.ReportAttributeValidValueDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.service.ReportAttributeValidValueService;
import com.prudential.pgim.fi.emir.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.SortDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/reportAttributeValidValues")
public class ReportAttributeValidValueController {

    private final ReportAttributeValidValueService reportAttributeValidValueService;

    public ReportAttributeValidValueController(
            final ReportAttributeValidValueService reportAttributeValidValueService) {
        this.reportAttributeValidValueService = reportAttributeValidValueService;
    }

    @GetMapping
    public String list(@RequestParam(required = false) final String filter,
            @SortDefault(sort = "id") @PageableDefault(size = 20) final Pageable pageable,
            final Model model) {
        final SimplePage<ReportAttributeValidValueDTO> reportAttributeValidValues = reportAttributeValidValueService.findAll(filter, pageable);
        model.addAttribute("reportAttributeValidValues", reportAttributeValidValues);
        model.addAttribute("filter", filter);
        model.addAttribute("paginationModel", WebUtils.getPaginationModel(reportAttributeValidValues));
        return "reportAttributeValidValue/list";
    }

    @GetMapping("/add")
    public String add(
            @ModelAttribute("reportAttributeValidValue") final ReportAttributeValidValueDTO reportAttributeValidValueDTO) {
        return "reportAttributeValidValue/add";
    }

    @PostMapping("/add")
    public String add(
            @ModelAttribute("reportAttributeValidValue") @Valid final ReportAttributeValidValueDTO reportAttributeValidValueDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (!bindingResult.hasFieldErrors("attributeValue") && reportAttributeValidValueService.attributeValueExists(reportAttributeValidValueDTO.getAttributeValue())) {
            bindingResult.rejectValue("attributeValue", "Exists.reportAttributeValidValue.attributeValue");
        }
        if (bindingResult.hasErrors()) {
            return "reportAttributeValidValue/add";
        }
        reportAttributeValidValueService.create(reportAttributeValidValueDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("reportAttributeValidValue.create.success"));
        return "redirect:/reportAttributeValidValues";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable final Long id, final Model model) {
        model.addAttribute("reportAttributeValidValue", reportAttributeValidValueService.get(id));
        return "reportAttributeValidValue/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable final Long id,
            @ModelAttribute("reportAttributeValidValue") @Valid final ReportAttributeValidValueDTO reportAttributeValidValueDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        final ReportAttributeValidValueDTO currentReportAttributeValidValueDTO = reportAttributeValidValueService.get(id);
        if (!bindingResult.hasFieldErrors("attributeValue") &&
                !reportAttributeValidValueDTO.getAttributeValue().equalsIgnoreCase(currentReportAttributeValidValueDTO.getAttributeValue()) &&
                reportAttributeValidValueService.attributeValueExists(reportAttributeValidValueDTO.getAttributeValue())) {
            bindingResult.rejectValue("attributeValue", "Exists.reportAttributeValidValue.attributeValue");
        }
        if (bindingResult.hasErrors()) {
            return "reportAttributeValidValue/edit";
        }
        reportAttributeValidValueService.update(id, reportAttributeValidValueDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("reportAttributeValidValue.update.success"));
        return "redirect:/reportAttributeValidValues";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable final Long id, final RedirectAttributes redirectAttributes) {
        reportAttributeValidValueService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("reportAttributeValidValue.delete.success"));
        return "redirect:/reportAttributeValidValues";
    }

}
