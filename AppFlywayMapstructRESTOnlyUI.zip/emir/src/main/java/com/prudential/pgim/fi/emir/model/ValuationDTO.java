package com.prudential.pgim.fi.emir.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ValuationDTO {

    private Long id;

    @NotNull
    @Size(max = 9)
    private String cusip;

    @NotNull
    private Integer fund;

    @NotNull
    @Size(max = 50)
    private String portfolio;

    @NotNull
    private Double posCurFace;

    @NotNull
    private Double posCurPar;

}
