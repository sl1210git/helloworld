package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.ReportTypeDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import org.springframework.data.domain.Pageable;


public interface ReportTypeService {

    SimplePage<ReportTypeDTO> findAll(String filter, Pageable pageable);

    ReportTypeDTO get(Long id);

    Long create(ReportTypeDTO reportTypeDTO);

    void update(Long id, ReportTypeDTO reportTypeDTO);

    void delete(Long id);

    boolean nameExists(String name);

}
