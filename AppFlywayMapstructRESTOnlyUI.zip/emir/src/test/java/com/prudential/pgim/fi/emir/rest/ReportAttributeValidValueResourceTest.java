package com.prudential.pgim.fi.emir.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.emir.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class ReportAttributeValidValueResourceTest extends BaseIT {

    @Test
    @Sql("/data/reportAttributeValidValueData.sql")
    void getAllReportAttributeValidValues_success() throws Exception {
        mockMvc.perform(get("/api/reportAttributeValidValues")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.content[0].id").value(((long)1500)));
    }

    @Test
    @Sql("/data/reportAttributeValidValueData.sql")
    void getAllReportAttributeValidValues_filtered() throws Exception {
        mockMvc.perform(get("/api/reportAttributeValidValues?filter=1501")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.content[0].id").value(((long)1501)));
    }

    @Test
    @Sql("/data/reportAttributeValidValueData.sql")
    void getReportAttributeValidValue_success() throws Exception {
        mockMvc.perform(get("/api/reportAttributeValidValues/1500")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.attributeValue").value("Sed ut perspiciatis."));
    }

    @Test
    void getReportAttributeValidValue_notFound() throws Exception {
        mockMvc.perform(get("/api/reportAttributeValidValues/2166")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createReportAttributeValidValue_success() throws Exception {
        mockMvc.perform(post("/api/reportAttributeValidValues")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportAttributeValidValueDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, reportAttributeValidValueRepository.count());
    }

    @Test
    void createReportAttributeValidValue_missingField() throws Exception {
        mockMvc.perform(post("/api/reportAttributeValidValues")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportAttributeValidValueDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("attributeValue"));
    }

    @Test
    @Sql("/data/reportAttributeValidValueData.sql")
    void updateReportAttributeValidValue_success() throws Exception {
        mockMvc.perform(put("/api/reportAttributeValidValues/1500")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportAttributeValidValueDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Duis autem vel.", reportAttributeValidValueRepository.findById(((long)1500)).get().getAttributeValue());
        assertEquals(2, reportAttributeValidValueRepository.count());
    }

    @Test
    @Sql("/data/reportAttributeValidValueData.sql")
    void deleteReportAttributeValidValue_success() throws Exception {
        mockMvc.perform(delete("/api/reportAttributeValidValues/1500")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, reportAttributeValidValueRepository.count());
    }

}
