package com.prudential.pgim.fi.emir.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.emir.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class TradeResourceTest extends BaseIT {

    @Test
    @Sql("/data/tradeData.sql")
    void getAllTrades_success() throws Exception {
        mockMvc.perform(get("/api/trades")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(((long)1100)));
    }

    @Test
    @Sql("/data/tradeData.sql")
    void getTrade_success() throws Exception {
        mockMvc.perform(get("/api/trades/1100")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cusip").value("Ut wisi e"));
    }

    @Test
    void getTrade_notFound() throws Exception {
        mockMvc.perform(get("/api/trades/1766")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createTrade_success() throws Exception {
        mockMvc.perform(post("/api/trades")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/tradeDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, tradeRepository.count());
    }

    @Test
    void createTrade_missingField() throws Exception {
        mockMvc.perform(post("/api/trades")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/tradeDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("cusip"));
    }

    @Test
    @Sql("/data/tradeData.sql")
    void updateTrade_success() throws Exception {
        mockMvc.perform(put("/api/trades/1100")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/tradeDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Sed ut pe", tradeRepository.findById(((long)1100)).get().getCusip());
        assertEquals(2, tradeRepository.count());
    }

    @Test
    @Sql("/data/tradeData.sql")
    void deleteTrade_success() throws Exception {
        mockMvc.perform(delete("/api/trades/1100")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, tradeRepository.count());
    }

}
