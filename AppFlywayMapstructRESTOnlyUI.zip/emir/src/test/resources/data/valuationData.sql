INSERT INTO valuation (
    id,
    cusip,
    fund,
    portfolio,
    pos_cur_face,
    pos_cur_par,
    date_created,
    last_updated
) VALUES (
    1200,
    'Ut wisi e',
    29,
    'Nam liber tempor.',
    53.42,
    81.42,
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO valuation (
    id,
    cusip,
    fund,
    portfolio,
    pos_cur_face,
    pos_cur_par,
    date_created,
    last_updated
) VALUES (
    1201,
    'Nam liber',
    30,
    'Sed ut perspiciatis.',
    54.42,
    82.42,
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
