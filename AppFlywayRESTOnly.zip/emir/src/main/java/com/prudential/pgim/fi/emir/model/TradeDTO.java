package com.prudential.pgim.fi.emir.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class TradeDTO {

    private Long id;

    @NotNull
    @Size(max = 9)
    private String cusip;

    @NotNull
    private Integer fund;

    @NotNull
    @Size(max = 50)
    private String portfolio;

    @NotNull
    @Size(max = 255)
    private String productClass;

    @NotNull
    @Size(max = 255)
    private String assetClass;

    @NotNull
    @Size(max = 255)
    private String contactType;

}
