package com.prudential.pgim.fi.emir.repos;

import com.prudential.pgim.fi.emir.domain.ReportAttribute;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ReportAttributeRepository extends JpaRepository<ReportAttribute, Long> {

    Page<ReportAttribute> findAllById(Long id, Pageable pageable);

    boolean existsByNameIgnoreCase(String name);

}
