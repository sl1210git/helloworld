package com.prudential.pgim.fi.emir.repos;

import com.prudential.pgim.fi.emir.domain.Trade;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TradeRepository extends JpaRepository<Trade, Long> {
}
