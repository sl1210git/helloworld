package com.prudential.pgim.fi.emir.rest;

import com.prudential.pgim.fi.emir.model.ValuationDTO;
import com.prudential.pgim.fi.emir.service.ValuationService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/valuations", produces = MediaType.APPLICATION_JSON_VALUE)
public class ValuationResource {

    private final ValuationService valuationService;

    public ValuationResource(final ValuationService valuationService) {
        this.valuationService = valuationService;
    }

    @GetMapping
    public ResponseEntity<List<ValuationDTO>> getAllValuations() {
        return ResponseEntity.ok(valuationService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ValuationDTO> getValuation(@PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(valuationService.get(id));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createValuation(
            @RequestBody @Valid final ValuationDTO valuationDTO) {
        final Long createdId = valuationService.create(valuationDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateValuation(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final ValuationDTO valuationDTO) {
        valuationService.update(id, valuationDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteValuation(@PathVariable(name = "id") final Long id) {
        valuationService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
