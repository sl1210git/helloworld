package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.ReportAttributeDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import org.springframework.data.domain.Pageable;


public interface ReportAttributeService {

    SimplePage<ReportAttributeDTO> findAll(String filter, Pageable pageable);

    ReportAttributeDTO get(Long id);

    Long create(ReportAttributeDTO reportAttributeDTO);

    void update(Long id, ReportAttributeDTO reportAttributeDTO);

    void delete(Long id);

    boolean nameExists(String name);

}
