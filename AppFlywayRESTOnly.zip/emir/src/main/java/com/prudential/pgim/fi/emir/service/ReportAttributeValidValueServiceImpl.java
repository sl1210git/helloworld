package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.ReportAttributeValidValue;
import com.prudential.pgim.fi.emir.model.ReportAttributeValidValueDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.ReportAttributeValidValueRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportAttributeValidValueServiceImpl implements ReportAttributeValidValueService {

    private final ReportAttributeValidValueRepository reportAttributeValidValueRepository;

    public ReportAttributeValidValueServiceImpl(
            final ReportAttributeValidValueRepository reportAttributeValidValueRepository) {
        this.reportAttributeValidValueRepository = reportAttributeValidValueRepository;
    }

    @Override
    public SimplePage<ReportAttributeValidValueDTO> findAll(final String filter,
            final Pageable pageable) {
        Page<ReportAttributeValidValue> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportAttributeValidValueRepository.findAllById(longFilter, pageable);
        } else {
            page = reportAttributeValidValueRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportAttributeValidValue -> mapToDTO(reportAttributeValidValue, new ReportAttributeValidValueDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportAttributeValidValueDTO get(final Long id) {
        return reportAttributeValidValueRepository.findById(id)
                .map(reportAttributeValidValue -> mapToDTO(reportAttributeValidValue, new ReportAttributeValidValueDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ReportAttributeValidValueDTO reportAttributeValidValueDTO) {
        final ReportAttributeValidValue reportAttributeValidValue = new ReportAttributeValidValue();
        mapToEntity(reportAttributeValidValueDTO, reportAttributeValidValue);
        return reportAttributeValidValueRepository.save(reportAttributeValidValue).getId();
    }

    @Override
    public void update(final Long id,
            final ReportAttributeValidValueDTO reportAttributeValidValueDTO) {
        final ReportAttributeValidValue reportAttributeValidValue = reportAttributeValidValueRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(reportAttributeValidValueDTO, reportAttributeValidValue);
        reportAttributeValidValueRepository.save(reportAttributeValidValue);
    }

    @Override
    public void delete(final Long id) {
        reportAttributeValidValueRepository.deleteById(id);
    }

    private ReportAttributeValidValueDTO mapToDTO(
            final ReportAttributeValidValue reportAttributeValidValue,
            final ReportAttributeValidValueDTO reportAttributeValidValueDTO) {
        reportAttributeValidValueDTO.setId(reportAttributeValidValue.getId());
        reportAttributeValidValueDTO.setAttributeValue(reportAttributeValidValue.getAttributeValue());
        reportAttributeValidValueDTO.setDisplayName(reportAttributeValidValue.getDisplayName());
        reportAttributeValidValueDTO.setValue(reportAttributeValidValue.getValue());
        reportAttributeValidValueDTO.setOrdering(reportAttributeValidValue.getOrdering());
        reportAttributeValidValueDTO.setCreatedById(reportAttributeValidValue.getCreatedById());
        reportAttributeValidValueDTO.setRevisedById(reportAttributeValidValue.getRevisedById());
        return reportAttributeValidValueDTO;
    }

    private ReportAttributeValidValue mapToEntity(
            final ReportAttributeValidValueDTO reportAttributeValidValueDTO,
            final ReportAttributeValidValue reportAttributeValidValue) {
        reportAttributeValidValue.setAttributeValue(reportAttributeValidValueDTO.getAttributeValue());
        reportAttributeValidValue.setDisplayName(reportAttributeValidValueDTO.getDisplayName());
        reportAttributeValidValue.setValue(reportAttributeValidValueDTO.getValue());
        reportAttributeValidValue.setOrdering(reportAttributeValidValueDTO.getOrdering());
        reportAttributeValidValue.setCreatedById(reportAttributeValidValueDTO.getCreatedById());
        reportAttributeValidValue.setRevisedById(reportAttributeValidValueDTO.getRevisedById());
        return reportAttributeValidValue;
    }

    @Override
    public boolean attributeValueExists(final String attributeValue) {
        return reportAttributeValidValueRepository.existsByAttributeValueIgnoreCase(attributeValue);
    }

}
