package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.ReportType;
import com.prudential.pgim.fi.emir.model.ReportTypeDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.ReportTypeRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportTypeServiceImpl implements ReportTypeService {

    private final ReportTypeRepository reportTypeRepository;

    public ReportTypeServiceImpl(final ReportTypeRepository reportTypeRepository) {
        this.reportTypeRepository = reportTypeRepository;
    }

    @Override
    public SimplePage<ReportTypeDTO> findAll(final String filter, final Pageable pageable) {
        Page<ReportType> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportTypeRepository.findAllById(longFilter, pageable);
        } else {
            page = reportTypeRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportType -> mapToDTO(reportType, new ReportTypeDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportTypeDTO get(final Long id) {
        return reportTypeRepository.findById(id)
                .map(reportType -> mapToDTO(reportType, new ReportTypeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ReportTypeDTO reportTypeDTO) {
        final ReportType reportType = new ReportType();
        mapToEntity(reportTypeDTO, reportType);
        return reportTypeRepository.save(reportType).getId();
    }

    @Override
    public void update(final Long id, final ReportTypeDTO reportTypeDTO) {
        final ReportType reportType = reportTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(reportTypeDTO, reportType);
        reportTypeRepository.save(reportType);
    }

    @Override
    public void delete(final Long id) {
        reportTypeRepository.deleteById(id);
    }

    private ReportTypeDTO mapToDTO(final ReportType reportType, final ReportTypeDTO reportTypeDTO) {
        reportTypeDTO.setId(reportType.getId());
        reportTypeDTO.setName(reportType.getName());
        reportTypeDTO.setDescription(reportType.getDescription());
        reportTypeDTO.setDisplayName(reportType.getDisplayName());
        reportTypeDTO.setCreatedById(reportType.getCreatedById());
        reportTypeDTO.setRevisedById(reportType.getRevisedById());
        return reportTypeDTO;
    }

    private ReportType mapToEntity(final ReportTypeDTO reportTypeDTO, final ReportType reportType) {
        reportType.setName(reportTypeDTO.getName());
        reportType.setDescription(reportTypeDTO.getDescription());
        reportType.setDisplayName(reportTypeDTO.getDisplayName());
        reportType.setCreatedById(reportTypeDTO.getCreatedById());
        reportType.setRevisedById(reportTypeDTO.getRevisedById());
        return reportType;
    }

    @Override
    public boolean nameExists(final String name) {
        return reportTypeRepository.existsByNameIgnoreCase(name);
    }

}
