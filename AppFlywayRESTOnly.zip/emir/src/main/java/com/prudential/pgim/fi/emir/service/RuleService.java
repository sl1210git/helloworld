package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.RuleDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import org.springframework.data.domain.Pageable;


public interface RuleService {

    SimplePage<RuleDTO> findAll(String filter, Pageable pageable);

    RuleDTO get(Long id);

    Long create(RuleDTO ruleDTO);

    void update(Long id, RuleDTO ruleDTO);

    void delete(Long id);

    boolean nameExists(String name);

}
