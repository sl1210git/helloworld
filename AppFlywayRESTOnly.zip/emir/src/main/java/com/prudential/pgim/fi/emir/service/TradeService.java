package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.TradeDTO;
import java.util.List;


public interface TradeService {

    List<TradeDTO> findAll();

    TradeDTO get(Long id);

    Long create(TradeDTO tradeDTO);

    void update(Long id, TradeDTO tradeDTO);

    void delete(Long id);

}
