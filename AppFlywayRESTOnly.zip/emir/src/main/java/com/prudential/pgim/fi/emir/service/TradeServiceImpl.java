package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Trade;
import com.prudential.pgim.fi.emir.model.TradeDTO;
import com.prudential.pgim.fi.emir.repos.TradeRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class TradeServiceImpl implements TradeService {

    private final TradeRepository tradeRepository;

    public TradeServiceImpl(final TradeRepository tradeRepository) {
        this.tradeRepository = tradeRepository;
    }

    @Override
    public List<TradeDTO> findAll() {
        final List<Trade> trades = tradeRepository.findAll(Sort.by("id"));
        return trades.stream()
                .map(trade -> mapToDTO(trade, new TradeDTO()))
                .toList();
    }

    @Override
    public TradeDTO get(final Long id) {
        return tradeRepository.findById(id)
                .map(trade -> mapToDTO(trade, new TradeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final TradeDTO tradeDTO) {
        final Trade trade = new Trade();
        mapToEntity(tradeDTO, trade);
        return tradeRepository.save(trade).getId();
    }

    @Override
    public void update(final Long id, final TradeDTO tradeDTO) {
        final Trade trade = tradeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(tradeDTO, trade);
        tradeRepository.save(trade);
    }

    @Override
    public void delete(final Long id) {
        tradeRepository.deleteById(id);
    }

    private TradeDTO mapToDTO(final Trade trade, final TradeDTO tradeDTO) {
        tradeDTO.setId(trade.getId());
        tradeDTO.setCusip(trade.getCusip());
        tradeDTO.setFund(trade.getFund());
        tradeDTO.setPortfolio(trade.getPortfolio());
        tradeDTO.setProductClass(trade.getProductClass());
        tradeDTO.setAssetClass(trade.getAssetClass());
        tradeDTO.setContactType(trade.getContactType());
        return tradeDTO;
    }

    private Trade mapToEntity(final TradeDTO tradeDTO, final Trade trade) {
        trade.setCusip(tradeDTO.getCusip());
        trade.setFund(tradeDTO.getFund());
        trade.setPortfolio(tradeDTO.getPortfolio());
        trade.setProductClass(tradeDTO.getProductClass());
        trade.setAssetClass(tradeDTO.getAssetClass());
        trade.setContactType(tradeDTO.getContactType());
        return trade;
    }

}
