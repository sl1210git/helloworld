package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Valuation;
import com.prudential.pgim.fi.emir.model.ValuationDTO;
import com.prudential.pgim.fi.emir.repos.ValuationRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ValuationServiceImpl implements ValuationService {

    private final ValuationRepository valuationRepository;

    public ValuationServiceImpl(final ValuationRepository valuationRepository) {
        this.valuationRepository = valuationRepository;
    }

    @Override
    public List<ValuationDTO> findAll() {
        final List<Valuation> valuations = valuationRepository.findAll(Sort.by("id"));
        return valuations.stream()
                .map(valuation -> mapToDTO(valuation, new ValuationDTO()))
                .toList();
    }

    @Override
    public ValuationDTO get(final Long id) {
        return valuationRepository.findById(id)
                .map(valuation -> mapToDTO(valuation, new ValuationDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final ValuationDTO valuationDTO) {
        final Valuation valuation = new Valuation();
        mapToEntity(valuationDTO, valuation);
        return valuationRepository.save(valuation).getId();
    }

    @Override
    public void update(final Long id, final ValuationDTO valuationDTO) {
        final Valuation valuation = valuationRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(valuationDTO, valuation);
        valuationRepository.save(valuation);
    }

    @Override
    public void delete(final Long id) {
        valuationRepository.deleteById(id);
    }

    private ValuationDTO mapToDTO(final Valuation valuation, final ValuationDTO valuationDTO) {
        valuationDTO.setId(valuation.getId());
        valuationDTO.setCusip(valuation.getCusip());
        valuationDTO.setFund(valuation.getFund());
        valuationDTO.setPortfolio(valuation.getPortfolio());
        valuationDTO.setPosCurFace(valuation.getPosCurFace());
        valuationDTO.setPosCurPar(valuation.getPosCurPar());
        return valuationDTO;
    }

    private Valuation mapToEntity(final ValuationDTO valuationDTO, final Valuation valuation) {
        valuation.setCusip(valuationDTO.getCusip());
        valuation.setFund(valuationDTO.getFund());
        valuation.setPortfolio(valuationDTO.getPortfolio());
        valuation.setPosCurFace(valuationDTO.getPosCurFace());
        valuation.setPosCurPar(valuationDTO.getPosCurPar());
        return valuation;
    }

}
