package com.prudential.pgim.fi.emir.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.emir.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class ReportAttributeResourceTest extends BaseIT {

    @Test
    @Sql("/data/reportAttributeData.sql")
    void getAllReportAttributes_success() throws Exception {
        mockMvc.perform(get("/api/reportAttributes")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.content[0].id").value(((long)1400)));
    }

    @Test
    @Sql("/data/reportAttributeData.sql")
    void getAllReportAttributes_filtered() throws Exception {
        mockMvc.perform(get("/api/reportAttributes?filter=1401")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.content[0].id").value(((long)1401)));
    }

    @Test
    @Sql("/data/reportAttributeData.sql")
    void getReportAttribute_success() throws Exception {
        mockMvc.perform(get("/api/reportAttributes/1400")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Duis autem vel."));
    }

    @Test
    void getReportAttribute_notFound() throws Exception {
        mockMvc.perform(get("/api/reportAttributes/2066")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createReportAttribute_success() throws Exception {
        mockMvc.perform(post("/api/reportAttributes")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportAttributeDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, reportAttributeRepository.count());
    }

    @Test
    void createReportAttribute_missingField() throws Exception {
        mockMvc.perform(post("/api/reportAttributes")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportAttributeDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("name"));
    }

    @Test
    @Sql("/data/reportAttributeData.sql")
    void updateReportAttribute_success() throws Exception {
        mockMvc.perform(put("/api/reportAttributes/1400")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportAttributeDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Nam liber tempor.", reportAttributeRepository.findById(((long)1400)).get().getName());
        assertEquals(2, reportAttributeRepository.count());
    }

    @Test
    @Sql("/data/reportAttributeData.sql")
    void deleteReportAttribute_success() throws Exception {
        mockMvc.perform(delete("/api/reportAttributes/1400")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, reportAttributeRepository.count());
    }

}
