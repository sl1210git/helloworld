INSERT INTO report_attribute (
    id,
    name,
    description,
    display_name,
    report_type_id,
    default_value,
    ordering,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1400,
    'Duis autem vel.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Ut wisi enim.',
    71,
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    78,
    'Duis autem vel.',
    'Lorem ipsum dolor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO report_attribute (
    id,
    name,
    description,
    display_name,
    report_type_id,
    default_value,
    ordering,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1401,
    'Ut wisi enim.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    'Nam liber tempor.',
    72,
    'Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.',
    79,
    'Ut wisi enim.',
    'Duis autem vel.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
