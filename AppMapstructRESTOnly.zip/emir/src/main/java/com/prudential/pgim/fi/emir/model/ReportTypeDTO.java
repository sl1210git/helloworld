package com.prudential.pgim.fi.emir.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ReportTypeDTO {

    private Long id;

    @NotNull
    @Size(max = 80)
    private String name;

    private String description;

    @NotNull
    @Size(max = 255)
    private String displayName;

    @Size(max = 50)
    private String createdById;

    @Size(max = 50)
    private String revisedById;

}
