package com.prudential.pgim.fi.emir.repos;

import com.prudential.pgim.fi.emir.domain.ReportAttributeValidValue;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ReportAttributeValidValueRepository extends JpaRepository<ReportAttributeValidValue, Long> {

    Page<ReportAttributeValidValue> findAllById(Long id, Pageable pageable);

    boolean existsByAttributeValueIgnoreCase(String attributeValue);

}
