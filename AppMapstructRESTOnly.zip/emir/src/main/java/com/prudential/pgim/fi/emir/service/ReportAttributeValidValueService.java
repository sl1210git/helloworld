package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.ReportAttributeValidValueDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import org.springframework.data.domain.Pageable;


public interface ReportAttributeValidValueService {

    SimplePage<ReportAttributeValidValueDTO> findAll(String filter, Pageable pageable);

    ReportAttributeValidValueDTO get(Long id);

    Long create(ReportAttributeValidValueDTO reportAttributeValidValueDTO);

    void update(Long id, ReportAttributeValidValueDTO reportAttributeValidValueDTO);

    void delete(Long id);

    boolean attributeValueExists(String attributeValue);

}
