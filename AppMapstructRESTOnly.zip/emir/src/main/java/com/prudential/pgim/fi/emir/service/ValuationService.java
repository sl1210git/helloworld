package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.ValuationDTO;
import java.util.List;


public interface ValuationService {

    List<ValuationDTO> findAll();

    ValuationDTO get(Long id);

    Long create(ValuationDTO valuationDTO);

    void update(Long id, ValuationDTO valuationDTO);

    void delete(Long id);

}
