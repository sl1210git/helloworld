INSERT INTO report_attribute_valid_value (
    id,
    attribute_value,
    display_name,
    value,
    ordering,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1500,
    'Sed ut perspiciatis.',
    'Ut wisi enim.',
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    78,
    'Duis autem vel.',
    'Lorem ipsum dolor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO report_attribute_valid_value (
    id,
    attribute_value,
    display_name,
    value,
    ordering,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1501,
    'Lorem ipsum dolor.',
    'Nam liber tempor.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    79,
    'Ut wisi enim.',
    'Duis autem vel.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
