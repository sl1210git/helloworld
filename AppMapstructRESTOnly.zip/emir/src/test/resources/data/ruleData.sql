INSERT INTO rule (
    id,
    name,
    description,
    if_condition,
    then_condition,
    ordering,
    group_name,
    disabled,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1000,
    'Duis autem vel.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    78,
    'Lorem ipsum dolor.',
    TRUE,
    'Duis autem vel.',
    'Lorem ipsum dolor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO rule (
    id,
    name,
    description,
    if_condition,
    then_condition,
    ordering,
    group_name,
    disabled,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1001,
    'Ut wisi enim.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.',
    79,
    'Duis autem vel.',
    FALSE,
    'Ut wisi enim.',
    'Duis autem vel.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
