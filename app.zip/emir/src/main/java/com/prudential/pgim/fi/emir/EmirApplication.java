package com.prudential.pgim.fi.emir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EmirApplication {

    public static void main(final String[] args) {
        SpringApplication.run(EmirApplication.class, args);
    }

}
