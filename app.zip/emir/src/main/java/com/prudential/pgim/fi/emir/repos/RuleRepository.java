package com.prudential.pgim.fi.emir.repos;

import com.prudential.pgim.fi.emir.domain.Rule;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RuleRepository extends JpaRepository<Rule, Long> {

    boolean existsByNameIgnoreCase(String name);

}
