package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.model.RuleDTO;
import java.util.List;


public interface RuleService {

    List<RuleDTO> findAll();

    RuleDTO get(Long id);

    Long create(RuleDTO ruleDTO);

    void update(Long id, RuleDTO ruleDTO);

    void delete(Long id);

    boolean nameExists(String name);

}
