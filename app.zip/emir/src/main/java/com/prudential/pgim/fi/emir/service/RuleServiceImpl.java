package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Rule;
import com.prudential.pgim.fi.emir.model.RuleDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.RuleRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class RuleServiceImpl implements RuleService {

    private final RuleRepository ruleRepository;

    public RuleServiceImpl(final RuleRepository ruleRepository) {
        this.ruleRepository = ruleRepository;
    }

    @Override
    public SimplePage<RuleDTO> findAll(final String filter, final Pageable pageable) {
        Page<Rule> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = ruleRepository.findAllById(longFilter, pageable);
        } else {
            page = ruleRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(rule -> mapToDTO(rule, new RuleDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public RuleDTO get(final Long id) {
        return ruleRepository.findById(id)
                .map(rule -> mapToDTO(rule, new RuleDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final RuleDTO ruleDTO) {
        final Rule rule = new Rule();
        mapToEntity(ruleDTO, rule);
        return ruleRepository.save(rule).getId();
    }

    @Override
    public void update(final Long id, final RuleDTO ruleDTO) {
        final Rule rule = ruleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(ruleDTO, rule);
        ruleRepository.save(rule);
    }

    @Override
    public void delete(final Long id) {
        ruleRepository.deleteById(id);
    }

    private RuleDTO mapToDTO(final Rule rule, final RuleDTO ruleDTO) {
        ruleDTO.setId(rule.getId());
        ruleDTO.setName(rule.getName());
        ruleDTO.setDescription(rule.getDescription());
        ruleDTO.setIfcondition(rule.getIfcondition());
        ruleDTO.setThencondition(rule.getThencondition());
        ruleDTO.setOrderNumber(rule.getOrderNumber());
        ruleDTO.setGroupName(rule.getGroupName());
        ruleDTO.setDisabled(rule.getDisabled());
        ruleDTO.setCreatedById(rule.getCreatedById());
        ruleDTO.setRevisedById(rule.getRevisedById());
        return ruleDTO;
    }

    private Rule mapToEntity(final RuleDTO ruleDTO, final Rule rule) {
        rule.setName(ruleDTO.getName());
        rule.setDescription(ruleDTO.getDescription());
        rule.setIfcondition(ruleDTO.getIfcondition());
        rule.setThencondition(ruleDTO.getThencondition());
        rule.setOrderNumber(ruleDTO.getOrderNumber());
        rule.setGroupName(ruleDTO.getGroupName());
        rule.setDisabled(ruleDTO.getDisabled());
        rule.setCreatedById(ruleDTO.getCreatedById());
        rule.setRevisedById(ruleDTO.getRevisedById());
        return rule;
    }

    @Override
    public boolean nameExists(final String name) {
        return ruleRepository.existsByNameIgnoreCase(name);
    }

}
