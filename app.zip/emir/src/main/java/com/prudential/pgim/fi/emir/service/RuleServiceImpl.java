package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Rule;
import com.prudential.pgim.fi.emir.model.RuleDTO;
import com.prudential.pgim.fi.emir.repos.RuleRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class RuleServiceImpl implements RuleService {

    private final RuleRepository ruleRepository;
    private final RuleMapper ruleMapper;

    public RuleServiceImpl(final RuleRepository ruleRepository, final RuleMapper ruleMapper) {
        this.ruleRepository = ruleRepository;
        this.ruleMapper = ruleMapper;
    }

    @Override
    public List<RuleDTO> findAll() {
        final List<Rule> rules = ruleRepository.findAll(Sort.by("id"));
        return rules.stream()
                .map(rule -> ruleMapper.updateRuleDTO(rule, new RuleDTO()))
                .toList();
    }

    @Override
    public RuleDTO get(final Long id) {
        return ruleRepository.findById(id)
                .map(rule -> ruleMapper.updateRuleDTO(rule, new RuleDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final RuleDTO ruleDTO) {
        final Rule rule = new Rule();
        ruleMapper.updateRule(ruleDTO, rule);
        return ruleRepository.save(rule).getId();
    }

    @Override
    public void update(final Long id, final RuleDTO ruleDTO) {
        final Rule rule = ruleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        ruleMapper.updateRule(ruleDTO, rule);
        ruleRepository.save(rule);
    }

    @Override
    public void delete(final Long id) {
        ruleRepository.deleteById(id);
    }

    @Override
    public boolean nameExists(final String name) {
        return ruleRepository.existsByNameIgnoreCase(name);
    }

}
