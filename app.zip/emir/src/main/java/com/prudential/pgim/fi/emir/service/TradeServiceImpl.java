package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Trade;
import com.prudential.pgim.fi.emir.model.TradeDTO;
import com.prudential.pgim.fi.emir.repos.TradeRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class TradeServiceImpl implements TradeService {

    private final TradeRepository tradeRepository;
    private final TradeMapper tradeMapper;

    public TradeServiceImpl(final TradeRepository tradeRepository, final TradeMapper tradeMapper) {
        this.tradeRepository = tradeRepository;
        this.tradeMapper = tradeMapper;
    }

    @Override
    public List<TradeDTO> findAll() {
        final List<Trade> trades = tradeRepository.findAll(Sort.by("id"));
        return trades.stream()
                .map(trade -> tradeMapper.updateTradeDTO(trade, new TradeDTO()))
                .toList();
    }

    @Override
    public TradeDTO get(final Long id) {
        return tradeRepository.findById(id)
                .map(trade -> tradeMapper.updateTradeDTO(trade, new TradeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final TradeDTO tradeDTO) {
        final Trade trade = new Trade();
        tradeMapper.updateTrade(tradeDTO, trade);
        return tradeRepository.save(trade).getId();
    }

    @Override
    public void update(final Long id, final TradeDTO tradeDTO) {
        final Trade trade = tradeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        tradeMapper.updateTrade(tradeDTO, trade);
        tradeRepository.save(trade);
    }

    @Override
    public void delete(final Long id) {
        tradeRepository.deleteById(id);
    }

}
