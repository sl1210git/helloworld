CREATE SEQUENCE  IF NOT EXISTS primary_sequence START WITH 10000 INCREMENT BY 1;

CREATE TABLE rule (
    id BIGINT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    ifcondition TEXT NOT NULL,
    thencondition TEXT NOT NULL,
    order_number INTEGER,
    group_name VARCHAR(255),
    disabled BOOLEAN NOT NULL,
    created_by_id VARCHAR(8),
    revised_by_id VARCHAR(8),
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT rule_pkey PRIMARY KEY (id)
);

CREATE TABLE trade (
    id BIGINT NOT NULL,
    cusip VARCHAR(9) NOT NULL,
    fund INTEGER NOT NULL,
    portfolio VARCHAR(50) NOT NULL,
    product_class VARCHAR(255) NOT NULL,
    asset_class VARCHAR(255) NOT NULL,
    contact_type VARCHAR(255) NOT NULL,
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT trade_pkey PRIMARY KEY (id)
);

CREATE TABLE valuation (
    id BIGINT NOT NULL,
    cusip VARCHAR(9) NOT NULL,
    fund INTEGER NOT NULL,
    portfolio VARCHAR(50) NOT NULL,
    pos_cur_face DOUBLE PRECISION NOT NULL,
    pos_cur_par DOUBLE PRECISION NOT NULL,
    date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    last_updated TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT valuation_pkey PRIMARY KEY (id)
);

ALTER TABLE rule ADD CONSTRAINT unique_rule_name UNIQUE (name);

