/**
 * Register an event at the document for the specified selector,
 * so events are still catched after DOM changes.
 */
function addEvent(eventType, selector, handler) {
    document.addEventListener(eventType, function(event) {
        if (event.target.matches(selector + ', ' + selector + ' *')) {
            handler.apply(event.target.closest(selector), arguments);
        }
    });
}

addEvent('change', '.js-selectlinks', function(event) {
    htmx.ajax('GET', this.value);
});
