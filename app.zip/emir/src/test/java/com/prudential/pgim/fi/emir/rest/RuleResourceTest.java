package com.prudential.pgim.fi.emir.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.emir.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class RuleResourceTest extends BaseIT {

    @Test
    @Sql("/data/ruleData.sql")
    void getAllRules_success() throws Exception {
        mockMvc.perform(get("/api/rules")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(((long)1000)));
    }

    @Test
    @Sql("/data/ruleData.sql")
    void getRule_success() throws Exception {
        mockMvc.perform(get("/api/rules/1000")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Duis autem vel."));
    }

    @Test
    void getRule_notFound() throws Exception {
        mockMvc.perform(get("/api/rules/1666")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createRule_success() throws Exception {
        mockMvc.perform(post("/api/rules")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/ruleDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, ruleRepository.count());
    }

    @Test
    void createRule_missingField() throws Exception {
        mockMvc.perform(post("/api/rules")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/ruleDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("name"));
    }

    @Test
    @Sql("/data/ruleData.sql")
    void updateRule_success() throws Exception {
        mockMvc.perform(put("/api/rules/1000")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/ruleDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Nam liber tempor.", ruleRepository.findById(((long)1000)).get().getName());
        assertEquals(2, ruleRepository.count());
    }

    @Test
    @Sql("/data/ruleData.sql")
    void deleteRule_success() throws Exception {
        mockMvc.perform(delete("/api/rules/1000")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, ruleRepository.count());
    }

}
