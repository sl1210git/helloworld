package com.prudential.pgim.fi.emir.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.emir.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class ValuationResourceTest extends BaseIT {

    @Test
    @Sql("/data/valuationData.sql")
    void getAllValuations_success() throws Exception {
        mockMvc.perform(get("/api/valuations")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(((long)1200)));
    }

    @Test
    @Sql("/data/valuationData.sql")
    void getValuation_success() throws Exception {
        mockMvc.perform(get("/api/valuations/1200")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cusip").value("Ut wisi e"));
    }

    @Test
    void getValuation_notFound() throws Exception {
        mockMvc.perform(get("/api/valuations/1866")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createValuation_success() throws Exception {
        mockMvc.perform(post("/api/valuations")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/valuationDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, valuationRepository.count());
    }

    @Test
    void createValuation_missingField() throws Exception {
        mockMvc.perform(post("/api/valuations")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/valuationDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("cusip"));
    }

    @Test
    @Sql("/data/valuationData.sql")
    void updateValuation_success() throws Exception {
        mockMvc.perform(put("/api/valuations/1200")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/valuationDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Sed ut pe", valuationRepository.findById(((long)1200)).get().getCusip());
        assertEquals(2, valuationRepository.count());
    }

    @Test
    @Sql("/data/valuationData.sql")
    void deleteValuation_success() throws Exception {
        mockMvc.perform(delete("/api/valuations/1200")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, valuationRepository.count());
    }

}
