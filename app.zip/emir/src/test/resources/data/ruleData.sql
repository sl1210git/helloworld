INSERT INTO rule (
    id,
    name,
    description,
    ifcondition,
    thencondition,
    order_number,
    group_name,
    disabled,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1000,
    'Duis autem vel.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
    11,
    'Lorem ipsum dolor.',
    TRUE,
    'Duis aut',
    'Lorem ip',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO rule (
    id,
    name,
    description,
    ifcondition,
    thencondition,
    order_number,
    group_name,
    disabled,
    created_by_id,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1001,
    'Ut wisi enim.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    12,
    'Duis autem vel.',
    FALSE,
    'Ut wisi',
    'Duis aut',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
