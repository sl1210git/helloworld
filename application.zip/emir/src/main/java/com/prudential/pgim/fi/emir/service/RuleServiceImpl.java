package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Rule;
import com.prudential.pgim.fi.emir.model.RuleDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.repos.RuleRepository;
import com.prudential.pgim.fi.emir.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class RuleServiceImpl implements RuleService {

    private final RuleRepository ruleRepository;
    private final RuleMapper ruleMapper;

    public RuleServiceImpl(final RuleRepository ruleRepository, final RuleMapper ruleMapper) {
        this.ruleRepository = ruleRepository;
        this.ruleMapper = ruleMapper;
    }

    @Override
    public SimplePage<RuleDTO> findAll(final String filter, final Pageable pageable) {
        Page<Rule> page;
        if (filter != null) {
            Long longFilter = null;
            try {
                longFilter = Long.parseLong(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = ruleRepository.findAllById(longFilter, pageable);
        } else {
            page = ruleRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(rule -> ruleMapper.updateRuleDTO(rule, new RuleDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public RuleDTO get(final Long id) {
        return ruleRepository.findById(id)
                .map(rule -> ruleMapper.updateRuleDTO(rule, new RuleDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Long create(final RuleDTO ruleDTO) {
        final Rule rule = new Rule();
        ruleMapper.updateRule(ruleDTO, rule);
        return ruleRepository.save(rule).getId();
    }

    @Override
    public void update(final Long id, final RuleDTO ruleDTO) {
        final Rule rule = ruleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        ruleMapper.updateRule(ruleDTO, rule);
        ruleRepository.save(rule);
    }

    @Override
    public void delete(final Long id) {
        ruleRepository.deleteById(id);
    }

    @Override
    public boolean nameExists(final String name) {
        return ruleRepository.existsByNameIgnoreCase(name);
    }

}
