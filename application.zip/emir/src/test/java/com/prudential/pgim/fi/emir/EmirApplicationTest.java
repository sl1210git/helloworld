package com.prudential.pgim.fi.emir;

import com.prudential.pgim.fi.emir.config.BaseIT;
import org.junit.jupiter.api.Test;


public class EmirApplicationTest extends BaseIT {

    @Test
    void contextLoads() {
    }

}
