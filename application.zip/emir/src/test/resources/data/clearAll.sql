DELETE FROM rule;

DELETE FROM trade;

DELETE FROM valuation;
