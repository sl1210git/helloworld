package com.prudential.pgim.fi.emir.controller;

import com.prudential.pgim.fi.emir.model.RuleDTO;
import com.prudential.pgim.fi.emir.model.SimplePage;
import com.prudential.pgim.fi.emir.service.RuleService;
import com.prudential.pgim.fi.emir.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.SortDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/rules")
public class RuleController {

    private final RuleService ruleService;

    public RuleController(final RuleService ruleService) {
        this.ruleService = ruleService;
    }

    @GetMapping
    public String list(@RequestParam(required = false) final String filter,
            @SortDefault(sort = "id") @PageableDefault(size = 20) final Pageable pageable,
            final Model model) {
        final SimplePage<RuleDTO> rules = ruleService.findAll(filter, pageable);
        model.addAttribute("rules", rules);
        model.addAttribute("filter", filter);
        model.addAttribute("paginationModel", WebUtils.getPaginationModel(rules));
        return "rule/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("rule") final RuleDTO ruleDTO) {
        return "rule/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("rule") @Valid final RuleDTO ruleDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (!bindingResult.hasFieldErrors("name") && ruleService.nameExists(ruleDTO.getName())) {
            bindingResult.rejectValue("name", "Exists.rule.name");
        }
        if (bindingResult.hasErrors()) {
            return "rule/add";
        }
        ruleService.create(ruleDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("rule.create.success"));
        return "redirect:/rules";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable final Long id, final Model model) {
        model.addAttribute("rule", ruleService.get(id));
        return "rule/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable final Long id,
            @ModelAttribute("rule") @Valid final RuleDTO ruleDTO, final BindingResult bindingResult,
            final RedirectAttributes redirectAttributes) {
        final RuleDTO currentRuleDTO = ruleService.get(id);
        if (!bindingResult.hasFieldErrors("name") &&
                !ruleDTO.getName().equalsIgnoreCase(currentRuleDTO.getName()) &&
                ruleService.nameExists(ruleDTO.getName())) {
            bindingResult.rejectValue("name", "Exists.rule.name");
        }
        if (bindingResult.hasErrors()) {
            return "rule/edit";
        }
        ruleService.update(id, ruleDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("rule.update.success"));
        return "redirect:/rules";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable final Long id, final RedirectAttributes redirectAttributes) {
        ruleService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("rule.delete.success"));
        return "redirect:/rules";
    }

}
