package com.prudential.pgim.fi.emir.controller;

import com.prudential.pgim.fi.emir.model.ValuationDTO;
import com.prudential.pgim.fi.emir.service.ValuationService;
import com.prudential.pgim.fi.emir.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/valuations")
public class ValuationController {

    private final ValuationService valuationService;

    public ValuationController(final ValuationService valuationService) {
        this.valuationService = valuationService;
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("valuations", valuationService.findAll());
        return "valuation/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("valuation") final ValuationDTO valuationDTO) {
        return "valuation/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("valuation") @Valid final ValuationDTO valuationDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "valuation/add";
        }
        valuationService.create(valuationDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("valuation.create.success"));
        return "redirect:/valuations";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable final Long id, final Model model) {
        model.addAttribute("valuation", valuationService.get(id));
        return "valuation/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable final Long id,
            @ModelAttribute("valuation") @Valid final ValuationDTO valuationDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "valuation/edit";
        }
        valuationService.update(id, valuationDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("valuation.update.success"));
        return "redirect:/valuations";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable final Long id, final RedirectAttributes redirectAttributes) {
        valuationService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("valuation.delete.success"));
        return "redirect:/valuations";
    }

}
