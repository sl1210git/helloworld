package com.prudential.pgim.fi.emir.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class RuleDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    private String name;

    private String description;

    @NotNull
    private String ifcondition;

    @NotNull
    private String thencondition;

    private Integer orderNumber;

    @Size(max = 255)
    private String groupName;

    @NotNull
    private Boolean disabled;

    @Size(max = 8)
    private String createdById;

    @Size(max = 8)
    private String revisedById;

}
