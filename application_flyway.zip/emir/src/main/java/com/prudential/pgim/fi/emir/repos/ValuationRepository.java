package com.prudential.pgim.fi.emir.repos;

import com.prudential.pgim.fi.emir.domain.Valuation;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ValuationRepository extends JpaRepository<Valuation, Long> {
}
