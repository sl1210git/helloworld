package com.prudential.pgim.fi.emir.rest;

import com.prudential.pgim.fi.emir.model.TradeDTO;
import com.prudential.pgim.fi.emir.service.TradeService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/trades", produces = MediaType.APPLICATION_JSON_VALUE)
public class TradeResource {

    private final TradeService tradeService;

    public TradeResource(final TradeService tradeService) {
        this.tradeService = tradeService;
    }

    @GetMapping
    public ResponseEntity<List<TradeDTO>> getAllTrades() {
        return ResponseEntity.ok(tradeService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TradeDTO> getTrade(@PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(tradeService.get(id));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createTrade(@RequestBody @Valid final TradeDTO tradeDTO) {
        final Long createdId = tradeService.create(tradeDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateTrade(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final TradeDTO tradeDTO) {
        tradeService.update(id, tradeDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteTrade(@PathVariable(name = "id") final Long id) {
        tradeService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
