package com.prudential.pgim.fi.emir.service;

import com.prudential.pgim.fi.emir.domain.Rule;
import com.prudential.pgim.fi.emir.model.RuleDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;


@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface RuleMapper {

    RuleDTO updateRuleDTO(Rule rule, @MappingTarget RuleDTO ruleDTO);

    @Mapping(target = "id", ignore = true)
    Rule updateRule(RuleDTO ruleDTO, @MappingTarget Rule rule);

}
