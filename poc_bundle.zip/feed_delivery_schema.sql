
-- =============================================
-- SQL Script: Feed Delivery Platform Metadata Tables
-- Author: OpenAI
-- Date: 2025-07-16
-- =============================================

-- Drop tables if they exist (for reruns)
IF OBJECT_ID('dbo.ExecutionLog', 'U') IS NOT NULL DROP TABLE dbo.ExecutionLog;
IF OBJECT_ID('dbo.FeedConfig', 'U') IS NOT NULL DROP TABLE dbo.FeedConfig;
IF OBJECT_ID('dbo.DeliveryCredentials', 'U') IS NOT NULL DROP TABLE dbo.DeliveryCredentials;

-- =============================================
-- Table: FeedConfig
-- =============================================
CREATE TABLE FeedConfig (
    FeedId INT IDENTITY(1,1) PRIMARY KEY,
    FeedName NVARCHAR(100) NOT NULL UNIQUE,
    Description NVARCHAR(255),

    -- Source Config
    SourceType NVARCHAR(50) NOT NULL,
    SourceQuery NVARCHAR(MAX) NOT NULL,

    -- Output Config
    OutputFormat NVARCHAR(20) NOT NULL,
    IncludeHeaders BIT DEFAULT 1,

    -- Delivery Config
    DeliveryType NVARCHAR(50) NOT NULL,
    DestinationPath NVARCHAR(255),
    DeliveryCredentialsRef NVARCHAR(100),

    -- Email-specific
    EmailSubject NVARCHAR(255),
    EmailBodyTemplate NVARCHAR(MAX),
    BundleReports BIT DEFAULT 0,

    -- Scheduling
    ScheduleType NVARCHAR(20) NOT NULL,
    CronExpression NVARCHAR(100),
    HolidayCalendarRef NVARCHAR(50),

    -- Audit
    IsActive BIT DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL,
    CreatedOn DATETIME DEFAULT GETDATE(),
    ModifiedBy NVARCHAR(100),
    ModifiedOn DATETIME
);

-- =============================================
-- Table: ExecutionLog
-- =============================================
CREATE TABLE ExecutionLog (
    ExecutionId UNIQUEIDENTIFIER DEFAULT NEWID() PRIMARY KEY,
    FeedId INT FOREIGN KEY REFERENCES FeedConfig(FeedId),
    FeedName NVARCHAR(100),

    TriggeredBy NVARCHAR(100),
    TriggeredOn DATETIME DEFAULT GETDATE(),

    ExecutionStatus NVARCHAR(20),
    StartTime DATETIME,
    EndTime DATETIME,

    OutputFilePath NVARCHAR(255),
    OutputFormat NVARCHAR(20),

    DeliveryStatus NVARCHAR(20),
    DeliveryTimestamp DATETIME,
    DeliveryError NVARCHAR(MAX),

    RetryCount INT DEFAULT 0,
    IsSuccess BIT,
    ErrorMessage NVARCHAR(MAX),

    LoggedOn DATETIME DEFAULT GETDATE()
);

-- =============================================
-- Table: DeliveryCredentials
-- =============================================
CREATE TABLE DeliveryCredentials (
    CredentialRef NVARCHAR(100) PRIMARY KEY,
    CredentialType NVARCHAR(50),
    SecretLocation NVARCHAR(255),
    CreatedOn DATETIME DEFAULT GETDATE()
);

-- =============================================
-- Sample FeedConfig Row
-- =============================================
INSERT INTO FeedConfig (
    FeedName, Description, SourceType, SourceQuery, OutputFormat,
    DeliveryType, DestinationPath, DeliveryCredentialsRef, ScheduleType,
    CronExpression, CreatedBy
) VALUES (
    'RegReport1',
    'Regulatory Report - Daily',
    'SQL',
    'SELECT * FROM RegulatoryFeedView',
    'CSV',
    'SFTP',
    '/sftp/clients/reg_report.csv',
    'SFTP_CRED_01',
    'Scheduled',
    '0 0 6 * * MON-FRI',
    'admin@company.com'
);
