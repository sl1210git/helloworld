
import paramiko
import os
import logging
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("SFTP Delivery Function triggered.")

    feed_name = req.params.get('feedName')
    file_path = req.params.get('filePath')
    destination = req.params.get('destinationPath')

    if not feed_name or not file_path or not destination:
        return func.HttpResponse("Missing parameters", status_code=400)

    hostname = os.getenv("SFTP_HOST")
    port = 22
    username = os.getenv("SFTP_USER")
    password = os.getenv("SFTP_PASS")

    transport = paramiko.Transport((hostname, port))
    transport.connect(username=username, password=password)

    sftp = paramiko.SFTPClient.from_transport(transport)

    try:
        local_file = f"/tmp/{os.path.basename(file_path)}"
        sftp.put(local_file, destination)
        logging.info(f"File delivered to {destination}")
        return func.HttpResponse("Success", status_code=200)
    except Exception as e:
        logging.error(f"Delivery failed: {str(e)}")
        return func.HttpResponse("Failed", status_code=500)
    finally:
        sftp.close()
        transport.close()
