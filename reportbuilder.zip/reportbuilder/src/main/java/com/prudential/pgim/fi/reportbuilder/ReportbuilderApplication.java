package com.prudential.pgim.fi.reportbuilder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ReportbuilderApplication {

    public static void main(final String[] args) {
        SpringApplication.run(ReportbuilderApplication.class, args);
    }

}
