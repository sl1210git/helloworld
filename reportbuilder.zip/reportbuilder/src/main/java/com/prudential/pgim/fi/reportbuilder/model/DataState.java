package com.prudential.pgim.fi.reportbuilder.model;


public enum DataState {

    TRUE,
    FALSE

}
