package com.prudential.pgim.fi.reportbuilder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ReportAttributeDTO {

    private Integer id;

    @NotNull
    @Size(max = 80)
    private String name;

    @NotNull
    @Size(max = 255)
    private String displayName;

    private String description;

    @NotNull
    private Integer reportTypeId;

    @Size(max = 4000)
    private String defaultValue;

    private String comment;

    private Integer displayOrder;

    @Size(max = 32)
    private String format;

    @NotNull
    @JsonProperty("isDisabled")
    private Boolean isDisabled;

    @NotNull
    @Size(max = 50)
    private String revisedById;

}
