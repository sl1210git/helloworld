package com.prudential.pgim.fi.reportbuilder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ReportRuleDTO {

    private Integer id;

    @NotNull
    @Size(max = 80)
    private String name;

    private String description;

    @NotNull
    private Integer reportTypeId;

    @NotNull
    private String ifCondition;

    @NotNull
    private String thenCondition;

    private Integer ordering;

    @Size(max = 80)
    private String groupName;

    @NotNull
    @JsonProperty("isDisabled")
    private Boolean isDisabled;

    @NotNull
    @Size(max = 50)
    private String revisedById;

}
