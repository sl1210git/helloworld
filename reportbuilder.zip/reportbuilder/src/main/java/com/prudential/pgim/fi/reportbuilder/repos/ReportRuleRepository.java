package com.prudential.pgim.fi.reportbuilder.repos;

import com.prudential.pgim.fi.reportbuilder.domain.ReportRule;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ReportRuleRepository extends JpaRepository<ReportRule, Integer> {

    Page<ReportRule> findAllById(Integer id, Pageable pageable);

    boolean existsByNameIgnoreCase(String name);

}
