package com.prudential.pgim.fi.reportbuilder.repos;

import com.prudential.pgim.fi.reportbuilder.domain.ReportType;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ReportTypeRepository extends JpaRepository<ReportType, Integer> {

    boolean existsByNameIgnoreCase(String name);

}
