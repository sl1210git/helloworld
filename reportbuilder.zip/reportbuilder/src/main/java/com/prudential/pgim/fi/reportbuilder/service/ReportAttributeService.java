package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.model.ReportAttributeDTO;
import com.prudential.pgim.fi.reportbuilder.model.SimplePage;
import org.springframework.data.domain.Pageable;


public interface ReportAttributeService {

    SimplePage<ReportAttributeDTO> findAll(String filter, Pageable pageable);

    ReportAttributeDTO get(Integer id);

    Integer create(ReportAttributeDTO reportAttributeDTO);

    void update(Integer id, ReportAttributeDTO reportAttributeDTO);

    void delete(Integer id);

}
