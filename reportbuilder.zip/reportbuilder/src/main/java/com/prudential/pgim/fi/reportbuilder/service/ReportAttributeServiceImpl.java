package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.domain.ReportAttribute;
import com.prudential.pgim.fi.reportbuilder.model.ReportAttributeDTO;
import com.prudential.pgim.fi.reportbuilder.model.SimplePage;
import com.prudential.pgim.fi.reportbuilder.repos.ReportAttributeRepository;
import com.prudential.pgim.fi.reportbuilder.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportAttributeServiceImpl implements ReportAttributeService {

    private final ReportAttributeRepository reportAttributeRepository;
    private final ReportAttributeMapper reportAttributeMapper;

    public ReportAttributeServiceImpl(final ReportAttributeRepository reportAttributeRepository,
            final ReportAttributeMapper reportAttributeMapper) {
        this.reportAttributeRepository = reportAttributeRepository;
        this.reportAttributeMapper = reportAttributeMapper;
    }

    @Override
    public SimplePage<ReportAttributeDTO> findAll(final String filter, final Pageable pageable) {
        Page<ReportAttribute> page;
        if (filter != null) {
            Integer integerFilter = null;
            try {
                integerFilter = Integer.parseInt(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportAttributeRepository.findAllById(integerFilter, pageable);
        } else {
            page = reportAttributeRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportAttribute -> reportAttributeMapper.updateReportAttributeDTO(reportAttribute, new ReportAttributeDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportAttributeDTO get(final Integer id) {
        return reportAttributeRepository.findById(id)
                .map(reportAttribute -> reportAttributeMapper.updateReportAttributeDTO(reportAttribute, new ReportAttributeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Integer create(final ReportAttributeDTO reportAttributeDTO) {
        final ReportAttribute reportAttribute = new ReportAttribute();
        reportAttributeMapper.updateReportAttribute(reportAttributeDTO, reportAttribute);
        return reportAttributeRepository.save(reportAttribute).getId();
    }

    @Override
    public void update(final Integer id, final ReportAttributeDTO reportAttributeDTO) {
        final ReportAttribute reportAttribute = reportAttributeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        reportAttributeMapper.updateReportAttribute(reportAttributeDTO, reportAttribute);
        reportAttributeRepository.save(reportAttribute);
    }

    @Override
    public void delete(final Integer id) {
        reportAttributeRepository.deleteById(id);
    }

}
