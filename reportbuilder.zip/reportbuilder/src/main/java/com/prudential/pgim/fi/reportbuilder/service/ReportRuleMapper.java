package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.domain.ReportRule;
import com.prudential.pgim.fi.reportbuilder.model.ReportRuleDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;


@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface ReportRuleMapper {

    ReportRuleDTO updateReportRuleDTO(ReportRule reportRule,
            @MappingTarget ReportRuleDTO reportRuleDTO);

    @Mapping(target = "id", ignore = true)
    ReportRule updateReportRule(ReportRuleDTO reportRuleDTO, @MappingTarget ReportRule reportRule);

}
