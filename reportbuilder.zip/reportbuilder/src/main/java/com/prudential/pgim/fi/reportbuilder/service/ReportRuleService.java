package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.model.ReportRuleDTO;
import com.prudential.pgim.fi.reportbuilder.model.SimplePage;
import org.springframework.data.domain.Pageable;


public interface ReportRuleService {

    SimplePage<ReportRuleDTO> findAll(String filter, Pageable pageable);

    ReportRuleDTO get(Integer id);

    Integer create(ReportRuleDTO reportRuleDTO);

    void update(Integer id, ReportRuleDTO reportRuleDTO);

    void delete(Integer id);

    boolean nameExists(String name);

}
