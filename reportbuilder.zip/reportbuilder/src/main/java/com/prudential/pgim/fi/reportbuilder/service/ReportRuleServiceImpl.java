package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.domain.ReportRule;
import com.prudential.pgim.fi.reportbuilder.model.ReportRuleDTO;
import com.prudential.pgim.fi.reportbuilder.model.SimplePage;
import com.prudential.pgim.fi.reportbuilder.repos.ReportRuleRepository;
import com.prudential.pgim.fi.reportbuilder.util.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class ReportRuleServiceImpl implements ReportRuleService {

    private final ReportRuleRepository reportRuleRepository;
    private final ReportRuleMapper reportRuleMapper;

    public ReportRuleServiceImpl(final ReportRuleRepository reportRuleRepository,
            final ReportRuleMapper reportRuleMapper) {
        this.reportRuleRepository = reportRuleRepository;
        this.reportRuleMapper = reportRuleMapper;
    }

    @Override
    public SimplePage<ReportRuleDTO> findAll(final String filter, final Pageable pageable) {
        Page<ReportRule> page;
        if (filter != null) {
            Integer integerFilter = null;
            try {
                integerFilter = Integer.parseInt(filter);
            } catch (final NumberFormatException numberFormatException) {
                // keep null - no parseable input
            }
            page = reportRuleRepository.findAllById(integerFilter, pageable);
        } else {
            page = reportRuleRepository.findAll(pageable);
        }
        return new SimplePage<>(page.getContent()
                .stream()
                .map(reportRule -> reportRuleMapper.updateReportRuleDTO(reportRule, new ReportRuleDTO()))
                .toList(),
                page.getTotalElements(), pageable);
    }

    @Override
    public ReportRuleDTO get(final Integer id) {
        return reportRuleRepository.findById(id)
                .map(reportRule -> reportRuleMapper.updateReportRuleDTO(reportRule, new ReportRuleDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Integer create(final ReportRuleDTO reportRuleDTO) {
        final ReportRule reportRule = new ReportRule();
        reportRuleMapper.updateReportRule(reportRuleDTO, reportRule);
        return reportRuleRepository.save(reportRule).getId();
    }

    @Override
    public void update(final Integer id, final ReportRuleDTO reportRuleDTO) {
        final ReportRule reportRule = reportRuleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        reportRuleMapper.updateReportRule(reportRuleDTO, reportRule);
        reportRuleRepository.save(reportRule);
    }

    @Override
    public void delete(final Integer id) {
        reportRuleRepository.deleteById(id);
    }

    @Override
    public boolean nameExists(final String name) {
        return reportRuleRepository.existsByNameIgnoreCase(name);
    }

}
