package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.model.ReportTypeDTO;
import java.util.List;


public interface ReportTypeService {

    List<ReportTypeDTO> findAll();

    ReportTypeDTO get(Integer id);

    Integer create(ReportTypeDTO reportTypeDTO);

    void update(Integer id, ReportTypeDTO reportTypeDTO);

    void delete(Integer id);

    boolean nameExists(String name);

}
