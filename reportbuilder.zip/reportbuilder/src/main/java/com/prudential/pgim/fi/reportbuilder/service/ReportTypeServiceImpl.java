package com.prudential.pgim.fi.reportbuilder.service;

import com.prudential.pgim.fi.reportbuilder.domain.ReportType;
import com.prudential.pgim.fi.reportbuilder.model.ReportTypeDTO;
import com.prudential.pgim.fi.reportbuilder.repos.ReportTypeRepository;
import com.prudential.pgim.fi.reportbuilder.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ReportTypeServiceImpl implements ReportTypeService {

    private final ReportTypeRepository reportTypeRepository;
    private final ReportTypeMapper reportTypeMapper;

    public ReportTypeServiceImpl(final ReportTypeRepository reportTypeRepository,
            final ReportTypeMapper reportTypeMapper) {
        this.reportTypeRepository = reportTypeRepository;
        this.reportTypeMapper = reportTypeMapper;
    }

    @Override
    public List<ReportTypeDTO> findAll() {
        final List<ReportType> reportTypes = reportTypeRepository.findAll(Sort.by("id"));
        return reportTypes.stream()
                .map(reportType -> reportTypeMapper.updateReportTypeDTO(reportType, new ReportTypeDTO()))
                .toList();
    }

    @Override
    public ReportTypeDTO get(final Integer id) {
        return reportTypeRepository.findById(id)
                .map(reportType -> reportTypeMapper.updateReportTypeDTO(reportType, new ReportTypeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    @Override
    public Integer create(final ReportTypeDTO reportTypeDTO) {
        final ReportType reportType = new ReportType();
        reportTypeMapper.updateReportType(reportTypeDTO, reportType);
        return reportTypeRepository.save(reportType).getId();
    }

    @Override
    public void update(final Integer id, final ReportTypeDTO reportTypeDTO) {
        final ReportType reportType = reportTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        reportTypeMapper.updateReportType(reportTypeDTO, reportType);
        reportTypeRepository.save(reportType);
    }

    @Override
    public void delete(final Integer id) {
        reportTypeRepository.deleteById(id);
    }

    @Override
    public boolean nameExists(final String name) {
        return reportTypeRepository.existsByNameIgnoreCase(name);
    }

}
