package com.prudential.pgim.fi.reportbuilder;

import com.prudential.pgim.fi.reportbuilder.config.BaseIT;
import org.junit.jupiter.api.Test;


public class ReportbuilderApplicationTest extends BaseIT {

    @Test
    void contextLoads() {
    }

}
