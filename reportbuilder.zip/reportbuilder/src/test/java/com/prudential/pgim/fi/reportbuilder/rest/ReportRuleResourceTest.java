package com.prudential.pgim.fi.reportbuilder.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.reportbuilder.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class ReportRuleResourceTest extends BaseIT {

    @Test
    @Sql("/data/reportRuleData.sql")
    void getAllReportRules_success() throws Exception {
        mockMvc.perform(get("/api/reportRules")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.content[0].id").value(((long)1000)));
    }

    @Test
    @Sql("/data/reportRuleData.sql")
    void getAllReportRules_filtered() throws Exception {
        mockMvc.perform(get("/api/reportRules?filter=1001")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.content[0].id").value(((long)1001)));
    }

    @Test
    @Sql("/data/reportRuleData.sql")
    void getReportRule_success() throws Exception {
        mockMvc.perform(get("/api/reportRules/1000")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Duis autem vel."));
    }

    @Test
    void getReportRule_notFound() throws Exception {
        mockMvc.perform(get("/api/reportRules/1666")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createReportRule_success() throws Exception {
        mockMvc.perform(post("/api/reportRules")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportRuleDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, reportRuleRepository.count());
    }

    @Test
    void createReportRule_missingField() throws Exception {
        mockMvc.perform(post("/api/reportRules")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportRuleDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("name"));
    }

    @Test
    @Sql("/data/reportRuleData.sql")
    void updateReportRule_success() throws Exception {
        mockMvc.perform(put("/api/reportRules/1000")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportRuleDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Nam liber tempor.", reportRuleRepository.findById(1000).get().getName());
        assertEquals(2, reportRuleRepository.count());
    }

    @Test
    @Sql("/data/reportRuleData.sql")
    void deleteReportRule_success() throws Exception {
        mockMvc.perform(delete("/api/reportRules/1000")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, reportRuleRepository.count());
    }

}
