package com.prudential.pgim.fi.reportbuilder.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.prudential.pgim.fi.reportbuilder.config.BaseIT;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;


public class ReportTypeResourceTest extends BaseIT {

    @Test
    @Sql("/data/reportTypeData.sql")
    void getAllReportTypes_success() throws Exception {
        mockMvc.perform(get("/api/reportTypes")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(((long)1100)));
    }

    @Test
    @Sql("/data/reportTypeData.sql")
    void getReportType_success() throws Exception {
        mockMvc.perform(get("/api/reportTypes/1100")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Duis autem vel."));
    }

    @Test
    void getReportType_notFound() throws Exception {
        mockMvc.perform(get("/api/reportTypes/1766")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.exception").value("NotFoundException"));
    }

    @Test
    void createReportType_success() throws Exception {
        mockMvc.perform(post("/api/reportTypes")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportTypeDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
        assertEquals(1, reportTypeRepository.count());
    }

    @Test
    void createReportType_missingField() throws Exception {
        mockMvc.perform(post("/api/reportTypes")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportTypeDTORequest_missingField.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.exception").value("MethodArgumentNotValidException"))
                .andExpect(jsonPath("$.fieldErrors[0].field").value("name"));
    }

    @Test
    @Sql("/data/reportTypeData.sql")
    void updateReportType_success() throws Exception {
        mockMvc.perform(put("/api/reportTypes/1100")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(readResource("/requests/reportTypeDTORequest.json"))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        assertEquals("Nam liber tempor.", reportTypeRepository.findById(1100).get().getName());
        assertEquals(2, reportTypeRepository.count());
    }

    @Test
    @Sql("/data/reportTypeData.sql")
    void deleteReportType_success() throws Exception {
        mockMvc.perform(delete("/api/reportTypes/1100")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
        assertEquals(1, reportTypeRepository.count());
    }

}
