DELETE FROM report_rule;

DELETE FROM report_type;

DELETE FROM report_attribute;
