INSERT INTO report_attribute (
    id,
    name,
    display_name,
    description,
    report_type_id,
    default_value,
    comment,
    display_order,
    format,
    is_disabled,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1200,
    'Duis autem vel.',
    'Ut wisi enim.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    71,
    'Ut wisi enim.',
    'Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.',
    44,
    'Duis autem vel.',
    TRUE,
    'Lorem ipsum dolor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO report_attribute (
    id,
    name,
    display_name,
    description,
    report_type_id,
    default_value,
    comment,
    display_order,
    format,
    is_disabled,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1201,
    'Ut wisi enim.',
    'Nam liber tempor.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    72,
    'Nam liber tempor.',
    'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
    45,
    'Ut wisi enim.',
    FALSE,
    'Duis autem vel.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
