INSERT INTO report_type (
    id,
    name,
    display_name,
    description,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1100,
    'Duis autem vel.',
    'Ut wisi enim.',
    'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.',
    'Lorem ipsum dolor.',
    '2023-09-02 16:30:00',
    '2023-09-02 16:30:00'
);

INSERT INTO report_type (
    id,
    name,
    display_name,
    description,
    revised_by_id,
    date_created,
    last_updated
) VALUES (
    1101,
    'Ut wisi enim.',
    'Nam liber tempor.',
    'Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.',
    'Duis autem vel.',
    '2023-09-03 16:30:00',
    '2023-09-03 16:30:00'
);
